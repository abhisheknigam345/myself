package com;

public class IDGenerator {
	
	public static int id;

}
