package com;

import java.util.ArrayList;

public class HospitalMgmtImpl implements IHospitalMgmt {
	
	private ArrayList<Doctor> doctorList;

	public ArrayList<Doctor> getDoctorList() {
		return doctorList;
	}

	public void setDoctorList(ArrayList<Doctor> doctorList) {
		this.doctorList = doctorList;
	}
	
	

	@Override
	public int registerDoctor(Doctor d) throws DuplicateDoctorException {
		int flag=0;
		for(int i=0;i<doctorList.size();i++){
			if(doctorList.get(i).getRegNo()==d.getRegNo()){
				flag=-1;
			}
		}
		if(flag==0){
			doctorList.add(d);
			return doctorList.size();
		}
		else{
			throw new DuplicateDoctorException();
		}
	}

	@Override
	public int hospitalizePatient(String s, Patient p) throws PatientExistException{
		int flag=0;
		int j=0;
		for(int i=0;i<doctorList.size();i++){
			if(doctorList.get(i).getRegNo().equalsIgnoreCase(s)){
				j=i;
				if(doctorList.get(i).getPatientList().contains(p)){
					flag=-1;
				}
			}
		}
		if(flag==0){
			doctorList.get(j).addPatient(p);
			return doctorList.get(j).getPatientList().size();
		}
		else{
			throw new PatientExistException();
		}
	}

	@Override
	public int releasePatient(int i) {
			return 0;
		}

	public Doctor retrieveDoctorInfo(int j) {
		
		
		return null;
	}

	@Override
	public int patientCountPerCity(String s) {
		int k=0;
		for(int i=0;i<doctorList.size();i++){
			for(int j=0;j<doctorList.get(i).getPatientList().size();i++){
				if(doctorList.get(i).getPatientList().get(j).getCity().equalsIgnoreCase(s)){
					k++;
				}
			}
		}
		return k;
	}

}
