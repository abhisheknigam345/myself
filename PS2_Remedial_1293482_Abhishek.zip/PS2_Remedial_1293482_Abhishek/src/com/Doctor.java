package com;

import java.util.ArrayList;

public class Doctor {
	
	private String regNo;
	private String docName;
	private ArrayList<Patient> patientList;
	
	public Doctor(String regNo, String docName) {
		super();
		this.regNo = regNo;
		this.docName = docName;
	}

	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}
	
	public ArrayList<Patient> getPatientList() {
		return patientList;
	}

	public void setPatientList(ArrayList<Patient> patientList) {
		this.patientList = patientList;
	}

	public int addPatient(Patient p){
		patientList.add(p);
		return 0;
	}
	
	public int releasePatient(Patient r){
		patientList.remove(r);
		return 0;
	}
}
