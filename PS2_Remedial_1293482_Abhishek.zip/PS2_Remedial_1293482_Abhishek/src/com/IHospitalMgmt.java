package com;

public interface IHospitalMgmt {
	
	public int registerDoctor(Doctor d) throws DuplicateDoctorException;
	
	public int hospitalizePatient(String s,Patient p) throws PatientExistException;
	
	public int releasePatient(int i);
	
	public Doctor retrieveDoctorInfo(int j);
	
	public int patientCountPerCity(String s);
	
	

}
