package com;

import java.util.ArrayList;

public class Test {
	
	public static void main(String[] args) {
		
		Patient p1=new Patient("101", "A", "Ahmedabad");
		Patient p2=new Patient("102", "B", "Mumbai");
		
		
		Doctor d1=new Doctor("1", "Abhishek");
		Doctor d2=new Doctor("2", "Vivek");
		Doctor d3=new Doctor("3", "Ankit");
		
		ArrayList<Doctor> d=new ArrayList<>();
		d.add(d1);
		d.add(d2);
		
		HospitalMgmtImpl hmi=new HospitalMgmtImpl();
		hmi.setDoctorList(d);
		
		int j=0; 
		try {
			j=hmi.registerDoctor(d3);
			System.out.println(j);
		} catch (DuplicateDoctorException e) {
			System.out.println("-1");
			System.out.println(e.getMessage());
		}
		
		int k=0;
		try {
			k=hmi.hospitalizePatient("1", p1);
			k=hmi.hospitalizePatient("2", p2);
			System.out.println(k);
		} catch (PatientExistException e) {
			System.out.println("-1");
			System.out.println(e.getMessage());
		}
		

	}

}
